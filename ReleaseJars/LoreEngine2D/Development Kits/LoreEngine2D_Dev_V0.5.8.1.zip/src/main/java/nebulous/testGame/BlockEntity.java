package nebulous.testGame;

import nebulous.Game;
import nebulous.addons.entity.simple.EntityMovable;

public class BlockEntity extends EntityMovable {

	public BlockEntity(float x, float y) {
		super(x,y);
	}

	@Override
	public void update(Game game, double delta) {
		
	}

}
