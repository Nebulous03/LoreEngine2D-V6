package example.game;

import nebulous.Game;
import nebulous.entity.simple.EntityMovable;

public class ExampleEntity extends EntityMovable {

	@Override
	public void update(Game game, double delta) {
		
	}
	

}
