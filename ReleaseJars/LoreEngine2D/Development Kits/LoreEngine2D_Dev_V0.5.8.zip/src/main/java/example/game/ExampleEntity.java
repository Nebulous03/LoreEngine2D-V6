package example.game;

import nebulous.Game;
import nebulous.addons.entity.simple.EntityMovable;

public class ExampleEntity extends EntityMovable {

	@Override
	public void update(Game game, double delta) {
		
	}
	

}
